# Verificación geométrica de candidatos (exploratorio, desarrollo)

58 sesiones, 988 consultas, 4401 pares.

## 1. Baseline (decisiones grabadas)

| Grupo | Tol | TP | FP | FN | P | R | F1 | FN alin. | FN opuestas |
|---|---|---|---|---|---|---|---|---|---|
| all | 2.0 | 199 | 36 | 162 | 0.847 | 0.551 | 0.668 | 18 | 144 |
| all | 1.0 | 130 | 105 | 44 | 0.553 | 0.747 | 0.636 | 3 | 41 |
| cold | 2.0 | 172 | 32 | 149 | 0.843 | 0.536 | 0.655 | 9 | 140 |
| cold | 1.0 | 118 | 86 | 38 | 0.578 | 0.756 | 0.656 | 0 | 38 |
| cid_sims | 2.0 | 27 | 4 | 13 | 0.871 | 0.675 | 0.761 | 9 | 4 |
| cid_sims | 1.0 | 12 | 19 | 6 | 0.387 | 0.667 | 0.490 | 3 | 3 |

Referencia Mac (CPU, mismas sesiones) a 2 m: TP 199, FP 37, FN 164. Sesiones con recuentos distintos: 3 de 58 (cold_freiburg_a_seq1_sunny2, cold_freiburg_a_seq2_night1, cold_freiburg_a_seq2_night2).

## 2. Techo de recuperación por apariencia (top-K sin puerta)

| Grupo | Tol | Oportunidades | con correcto en top-K | FN baseline | FN con correcto en top-K | alin. | opuestas |
|---|---|---|---|---|---|---|---|
| all | 2.0 | 361 | 260 | 162 | 113 | 17 | 96 |
| all | 1.0 | 174 | 105 | 44 | 22 | 3 | 19 |
| cold | 2.0 | 321 | 221 | 149 | 101 | 8 | 93 |
| cold | 1.0 | 156 | 88 | 38 | 17 | 0 | 17 |
| cid_sims | 2.0 | 40 | 39 | 13 | 12 | 9 | 3 |
| cid_sims | 1.0 | 18 | 17 | 6 | 5 | 3 | 2 |

## 3. Separabilidad (AUROC, pares top-K, positivo = distancia GT ≤ 2 m)

| Grupo | Puntuación | todos | alineados | opuestos | n+ alin. | n+ opuestos |
|---|---|---|---|---|---|---|
| all | lg_f_inliers | 0.657 | 0.909 | 0.620 | 43 | 300 |
| all | lg_matches | 0.642 | 0.902 | 0.604 | 43 | 300 |
| all | m_f_inliers | 0.626 | 0.855 | 0.593 | 43 | 300 |
| all | m_matches | 0.624 | 0.851 | 0.592 | 43 | 300 |
| all | visual_sim | 0.616 | 0.790 | 0.591 | 43 | 300 |
| cold | lg_f_inliers | 0.610 | 0.923 | 0.589 | 17 | 258 |
| cold | lg_matches | 0.593 | 0.923 | 0.571 | 17 | 258 |
| cold | m_f_inliers | 0.581 | 0.920 | 0.559 | 17 | 258 |
| cold | m_matches | 0.581 | 0.918 | 0.559 | 17 | 258 |
| cold | visual_sim | 0.604 | 0.871 | 0.586 | 17 | 258 |
| cid_sims | lg_f_inliers | 0.836 | 0.893 | 0.801 | 26 | 42 |
| cid_sims | lg_matches | 0.835 | 0.883 | 0.805 | 26 | 42 |
| cid_sims | m_f_inliers | 0.841 | 0.856 | 0.832 | 26 | 42 |
| cid_sims | m_matches | 0.841 | 0.857 | 0.832 | 26 | 42 |
| cid_sims | visual_sim | 0.774 | 0.856 | 0.723 | 26 | 42 |

## 4. Políticas «la apariencia propone, la geometría verifica» (2 m)

θ elegido dentro de la muestra (optimista) y transferido entre datasets. `union`: se conserva la aceptación del baseline y el verificador solo añade.

| Puntuación | Escala puerta | Modo | Selección θ | Evaluado en | θ | TP | FP | FN | P | R | F1 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| lg_f_inliers | 1 | replace | all | all | 19 | 101 | 25 | 260 | 0.802 | 0.280 | 0.415 |
| lg_f_inliers | 1 | replace | cold | cid_sims | 19 | 27 | 1 | 13 | 0.964 | 0.675 | 0.794 |
| lg_f_inliers | 1 | replace | cid_sims | cold | 19 | 74 | 24 | 247 | 0.755 | 0.231 | 0.353 |
| lg_f_inliers | 1 | union | all | all | 256 | 203 | 36 | 158 | 0.849 | 0.562 | 0.677 |
| lg_f_inliers | 1 | union | cold | cid_sims | 110 | 29 | 4 | 11 | 0.879 | 0.725 | 0.795 |
| lg_f_inliers | 1 | union | cid_sims | cold | 19 | 178 | 42 | 143 | 0.809 | 0.555 | 0.658 |
| lg_f_inliers | 4 | replace | all | all | 19 | 144 | 138 | 217 | 0.511 | 0.399 | 0.448 |
| lg_f_inliers | 4 | replace | cold | cid_sims | 19 | 29 | 19 | 11 | 0.604 | 0.725 | 0.659 |
| lg_f_inliers | 4 | replace | cid_sims | cold | 110 | 34 | 44 | 287 | 0.436 | 0.106 | 0.170 |
| lg_f_inliers | 4 | union | all | all | 20 | 253 | 125 | 108 | 0.669 | 0.701 | 0.685 |
| lg_f_inliers | 4 | union | cold | cid_sims | 20 | 35 | 17 | 5 | 0.673 | 0.875 | 0.761 |
| lg_f_inliers | 4 | union | cid_sims | cold | 126 | 183 | 53 | 138 | 0.775 | 0.570 | 0.657 |
| lg_f_inliers | 16 | replace | all | all | 19 | 111 | 506 | 250 | 0.180 | 0.307 | 0.227 |
| lg_f_inliers | 16 | replace | cold | cid_sims | 19 | 28 | 31 | 12 | 0.475 | 0.700 | 0.566 |
| lg_f_inliers | 16 | replace | cid_sims | cold | 110 | 34 | 132 | 287 | 0.205 | 0.106 | 0.140 |
| lg_f_inliers | 16 | union | all | all | 412.275 | 202 | 37 | 159 | 0.845 | 0.560 | 0.673 |
| lg_f_inliers | 16 | union | cold | cid_sims | 412.275 | 30 | 4 | 10 | 0.882 | 0.750 | 0.811 |
| lg_f_inliers | 16 | union | cid_sims | cold | 126 | 184 | 117 | 137 | 0.611 | 0.573 | 0.592 |
| lg_f_inliers | inf | replace | all | all | 110 | 60 | 169 | 301 | 0.262 | 0.166 | 0.203 |
| lg_f_inliers | inf | replace | cold | cid_sims | 19 | 28 | 32 | 12 | 0.467 | 0.700 | 0.560 |
| lg_f_inliers | inf | replace | cid_sims | cold | 110 | 34 | 160 | 287 | 0.175 | 0.106 | 0.132 |
| lg_f_inliers | inf | union | all | all | 412.275 | 202 | 47 | 159 | 0.811 | 0.560 | 0.662 |
| lg_f_inliers | inf | union | cold | cid_sims | 412.275 | 30 | 4 | 10 | 0.882 | 0.750 | 0.811 |
| lg_f_inliers | inf | union | cid_sims | cold | 126 | 184 | 141 | 137 | 0.566 | 0.573 | 0.570 |
| lg_matches | 1 | replace | all | all | 34 | 100 | 25 | 261 | 0.800 | 0.277 | 0.412 |
| lg_matches | 1 | replace | cold | cid_sims | 34 | 26 | 1 | 14 | 0.963 | 0.650 | 0.776 |
| lg_matches | 1 | replace | cid_sims | cold | 34 | 74 | 24 | 247 | 0.755 | 0.231 | 0.353 |
| lg_matches | 1 | union | all | all | 124 | 205 | 38 | 156 | 0.844 | 0.568 | 0.679 |
| lg_matches | 1 | union | cold | cid_sims | 95 | 30 | 4 | 10 | 0.882 | 0.750 | 0.811 |
| lg_matches | 1 | union | cid_sims | cold | 34 | 178 | 42 | 143 | 0.809 | 0.555 | 0.658 |
| lg_matches | 4 | replace | all | all | 34 | 143 | 135 | 218 | 0.514 | 0.396 | 0.448 |
| lg_matches | 4 | replace | cold | cid_sims | 34 | 29 | 20 | 11 | 0.592 | 0.725 | 0.652 |
| lg_matches | 4 | replace | cid_sims | cold | 167.387 | 33 | 38 | 288 | 0.465 | 0.103 | 0.168 |
| lg_matches | 4 | union | all | all | 35 | 252 | 121 | 109 | 0.676 | 0.698 | 0.687 |
| lg_matches | 4 | union | cold | cid_sims | 35 | 35 | 17 | 5 | 0.673 | 0.875 | 0.761 |
| lg_matches | 4 | union | cid_sims | cold | 167.387 | 183 | 54 | 138 | 0.772 | 0.570 | 0.656 |
| lg_matches | 16 | replace | all | all | 34 | 108 | 487 | 253 | 0.182 | 0.299 | 0.226 |
| lg_matches | 16 | replace | cold | cid_sims | 34 | 27 | 31 | 13 | 0.466 | 0.675 | 0.551 |
| lg_matches | 16 | replace | cid_sims | cold | 167.387 | 31 | 130 | 290 | 0.193 | 0.097 | 0.129 |
| lg_matches | 16 | union | all | all | 487.825 | 202 | 37 | 159 | 0.845 | 0.560 | 0.673 |
| lg_matches | 16 | union | cold | cid_sims | 487.825 | 30 | 4 | 10 | 0.882 | 0.750 | 0.811 |
| lg_matches | 16 | union | cid_sims | cold | 167.387 | 184 | 128 | 137 | 0.590 | 0.573 | 0.581 |
| lg_matches | inf | replace | all | all | 114 | 69 | 255 | 292 | 0.213 | 0.191 | 0.201 |
| lg_matches | inf | replace | cold | cid_sims | 34 | 27 | 31 | 13 | 0.466 | 0.675 | 0.551 |
| lg_matches | inf | replace | cid_sims | cold | 167.387 | 31 | 161 | 290 | 0.161 | 0.097 | 0.121 |
| lg_matches | inf | union | all | all | 487.825 | 203 | 46 | 158 | 0.815 | 0.562 | 0.666 |
| lg_matches | inf | union | cold | cid_sims | 487.825 | 30 | 4 | 10 | 0.882 | 0.750 | 0.811 |
| lg_matches | inf | union | cid_sims | cold | 167.387 | 184 | 153 | 137 | 0.546 | 0.573 | 0.559 |
| m_f_inliers | 1 | replace | all | all | 172 | 94 | 28 | 267 | 0.770 | 0.260 | 0.389 |
| m_f_inliers | 1 | replace | cold | cid_sims | 172 | 27 | 2 | 13 | 0.931 | 0.675 | 0.783 |
| m_f_inliers | 1 | replace | cid_sims | cold | 382 | 47 | 20 | 274 | 0.701 | 0.146 | 0.242 |
| m_f_inliers | 1 | union | all | all | 1978.39 | 205 | 38 | 156 | 0.844 | 0.568 | 0.679 |
| m_f_inliers | 1 | union | cold | cid_sims | 1978.39 | 29 | 4 | 11 | 0.879 | 0.725 | 0.795 |
| m_f_inliers | 1 | union | cid_sims | cold | 172 | 178 | 43 | 143 | 0.805 | 0.555 | 0.657 |
| m_f_inliers | 4 | replace | all | all | 172 | 137 | 149 | 224 | 0.479 | 0.380 | 0.423 |
| m_f_inliers | 4 | replace | cold | cid_sims | 172 | 29 | 20 | 11 | 0.592 | 0.725 | 0.652 |
| m_f_inliers | 4 | replace | cid_sims | cold | 584.98 | 77 | 89 | 244 | 0.464 | 0.240 | 0.316 |
| m_f_inliers | 4 | union | all | all | 2523 | 213 | 49 | 148 | 0.813 | 0.590 | 0.684 |
| m_f_inliers | 4 | union | cold | cid_sims | 382 | 34 | 16 | 6 | 0.680 | 0.850 | 0.756 |
| m_f_inliers | 4 | union | cid_sims | cold | 1623 | 187 | 64 | 134 | 0.745 | 0.583 | 0.654 |
| m_f_inliers | 16 | replace | all | all | 340.222 | 96 | 440 | 265 | 0.179 | 0.266 | 0.214 |
| m_f_inliers | 16 | replace | cold | cid_sims | 340.222 | 26 | 27 | 14 | 0.491 | 0.650 | 0.559 |
| m_f_inliers | 16 | replace | cid_sims | cold | 1218.36 | 44 | 239 | 277 | 0.155 | 0.137 | 0.146 |
| m_f_inliers | 16 | union | all | all | 2898 | 200 | 43 | 161 | 0.823 | 0.554 | 0.662 |
| m_f_inliers | 16 | union | cold | cid_sims | 2898 | 27 | 4 | 13 | 0.871 | 0.675 | 0.761 |
| m_f_inliers | 16 | union | cid_sims | cold | 1978.39 | 185 | 143 | 136 | 0.564 | 0.576 | 0.570 |
| m_f_inliers | inf | replace | all | all | 1490.08 | 62 | 270 | 299 | 0.187 | 0.172 | 0.179 |
| m_f_inliers | inf | replace | cold | cid_sims | 340.222 | 26 | 29 | 14 | 0.473 | 0.650 | 0.547 |
| m_f_inliers | inf | replace | cid_sims | cold | 1218.36 | 42 | 317 | 279 | 0.117 | 0.131 | 0.124 |
| m_f_inliers | inf | union | all | all | 2898 | 200 | 46 | 161 | 0.813 | 0.554 | 0.659 |
| m_f_inliers | inf | union | cold | cid_sims | 2898 | 27 | 4 | 13 | 0.871 | 0.675 | 0.761 |
| m_f_inliers | inf | union | cid_sims | cold | 1978.39 | 185 | 181 | 136 | 0.505 | 0.576 | 0.539 |
| m_matches | 1 | replace | all | all | 327.5 | 88 | 29 | 273 | 0.752 | 0.244 | 0.368 |
| m_matches | 1 | replace | cold | cid_sims | 327.5 | 26 | 2 | 14 | 0.929 | 0.650 | 0.765 |
| m_matches | 1 | replace | cid_sims | cold | 437 | 56 | 25 | 265 | 0.691 | 0.174 | 0.279 |
| m_matches | 1 | union | all | all | 2058.77 | 205 | 38 | 156 | 0.844 | 0.568 | 0.679 |
| m_matches | 1 | union | cold | cid_sims | 2058.77 | 29 | 4 | 11 | 0.879 | 0.725 | 0.795 |
| m_matches | 1 | union | cid_sims | cold | 327.5 | 177 | 43 | 144 | 0.805 | 0.551 | 0.654 |
| m_matches | 4 | replace | all | all | 351 | 135 | 149 | 226 | 0.475 | 0.374 | 0.419 |
| m_matches | 4 | replace | cold | cid_sims | 351 | 28 | 20 | 12 | 0.583 | 0.700 | 0.636 |
| m_matches | 4 | replace | cid_sims | cold | 605 | 84 | 103 | 237 | 0.449 | 0.262 | 0.331 |
| m_matches | 4 | union | all | all | 2560.75 | 213 | 49 | 148 | 0.813 | 0.590 | 0.684 |
| m_matches | 4 | union | cold | cid_sims | 381 | 34 | 17 | 6 | 0.667 | 0.850 | 0.747 |
| m_matches | 4 | union | cid_sims | cold | 1635.1 | 189 | 67 | 132 | 0.738 | 0.589 | 0.655 |
| m_matches | 16 | replace | all | all | 515 | 95 | 437 | 266 | 0.179 | 0.263 | 0.213 |
| m_matches | 16 | replace | cold | cid_sims | 515 | 26 | 26 | 14 | 0.500 | 0.650 | 0.565 |
| m_matches | 16 | replace | cid_sims | cold | 1501 | 44 | 229 | 277 | 0.161 | 0.137 | 0.148 |
| m_matches | 16 | union | all | all | 2917 | 202 | 42 | 159 | 0.828 | 0.560 | 0.668 |
| m_matches | 16 | union | cold | cid_sims | 2917 | 27 | 4 | 13 | 0.871 | 0.675 | 0.761 |
| m_matches | 16 | union | cid_sims | cold | 2058.77 | 186 | 142 | 135 | 0.567 | 0.579 | 0.573 |
| m_matches | inf | replace | all | all | 1379.36 | 67 | 319 | 294 | 0.174 | 0.186 | 0.179 |
| m_matches | inf | replace | cold | cid_sims | 437 | 26 | 29 | 14 | 0.473 | 0.650 | 0.547 |
| m_matches | inf | replace | cid_sims | cold | 1501 | 41 | 289 | 280 | 0.124 | 0.128 | 0.126 |
| m_matches | inf | union | all | all | 2917 | 202 | 45 | 159 | 0.818 | 0.560 | 0.664 |
| m_matches | inf | union | cold | cid_sims | 2917 | 27 | 4 | 13 | 0.871 | 0.675 | 0.761 |
| m_matches | inf | union | cid_sims | cold | 2058.77 | 186 | 178 | 135 | 0.511 | 0.579 | 0.543 |

## 5. Pose relativa en revisitas verdaderas (vistas con distancia GT ≤ 2 m)

Error absoluto mediano frente a GT. La odometría acumula la deriva entre ambos pasos.

| Grupo | n | MASt3R distancia (m) | odometría distancia (m) | MASt3R |giro| (°) | odometría |giro| (°) |
|---|---|---|---|---|---|
| all | 1143 | 0.48 | 0.39 | 14.0 | 9.8 |
| cold | 955 | 0.55 | 0.40 | 21.5 | 10.3 |
| cid_sims | 188 | 0.29 | 0.25 | 0.9 | 8.6 |

MASt3R: 0.213 s por par de imágenes (mediana, ambos sentidos).
